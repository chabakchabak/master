package com.chabakchabak.www.kim.mapper;

public interface UserMapper {
	//회원가입
//	public int join(UserVo vo);
}
