package com.chabakchabak.www.lee.domain.upload;

import lombok.Data;

@Data
public class ImgUploadDto {
	private boolean uploaded;
	private String url;
}
