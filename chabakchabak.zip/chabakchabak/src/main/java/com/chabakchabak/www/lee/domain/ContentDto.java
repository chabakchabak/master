package com.chabakchabak.www.lee.domain;

import lombok.Data;

@Data
public class ContentDto {
	private String content;
}
