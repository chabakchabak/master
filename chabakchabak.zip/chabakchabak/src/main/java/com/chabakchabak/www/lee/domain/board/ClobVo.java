package com.chabakchabak.www.lee.domain.board;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ClobVo {
	private String b_f_content;
}
