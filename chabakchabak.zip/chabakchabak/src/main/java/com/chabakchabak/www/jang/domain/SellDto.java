package com.chabakchabak.www.jang.domain;

import java.util.Date;

public class SellDto {
	private String imgPath;
	private String title;
	private String content;
	private String nickname;
	private Date regdate;
	private Date updatedate;
	private Date solddate;
}
