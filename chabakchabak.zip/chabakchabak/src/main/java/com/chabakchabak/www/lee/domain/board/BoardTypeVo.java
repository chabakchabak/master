package com.chabakchabak.www.lee.domain.board;

import lombok.Data;

@Data
public class BoardTypeVo {
	private Integer boardtypeno;
	private String boardtype;
}
