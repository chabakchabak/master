package com.chabakchabak.www.lee.domain.reply;

import lombok.Data;

@Data
public class ReplyLikeDto {
	private Integer replyno;
	private String userid;
	private String replyer;
}	
