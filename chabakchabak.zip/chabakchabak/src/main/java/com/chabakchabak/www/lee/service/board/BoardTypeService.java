package com.chabakchabak.www.lee.service.board;


public interface BoardTypeService {
	public String getBoardType(int boardtypeno);
	public int getBoardTypeNo(String boardtype);
}
