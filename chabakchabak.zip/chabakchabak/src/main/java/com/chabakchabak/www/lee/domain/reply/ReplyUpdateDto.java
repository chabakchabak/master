package com.chabakchabak.www.lee.domain.reply;

import lombok.Data;

@Data
public class ReplyUpdateDto {
	private Integer replyno;
	private String comments;
}
