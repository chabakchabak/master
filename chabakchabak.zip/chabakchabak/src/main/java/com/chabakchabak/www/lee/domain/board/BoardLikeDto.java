package com.chabakchabak.www.lee.domain.board;

import lombok.Data;

@Data
public class BoardLikeDto {
	private Integer boardno;
	private String userid;
}	
