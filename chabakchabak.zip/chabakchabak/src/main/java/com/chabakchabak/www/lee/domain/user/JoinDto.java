package com.chabakchabak.www.lee.domain.user;

import lombok.Data;

@Data
public class JoinDto {
	private String userid;
	private String userpw;
	private String nickname;
	private String email;
}
