package com.chabakchabak.www.lee.domain.user;

import lombok.Data;

@Data
public class LevelDto {
	private Integer userlevel;
	private Integer point;
	private String profile;
}
