package com.chabakchabak.www.lee.mapper.board;

public interface BoardTypeMapper {
	public String getBoardType(int boardtypeno);
	public int getBoardTypeNo(String boardtype);
}
