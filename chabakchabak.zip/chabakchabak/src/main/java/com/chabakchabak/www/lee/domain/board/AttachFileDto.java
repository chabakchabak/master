package com.chabakchabak.www.lee.domain.board;


import lombok.Data;

@Data
public class AttachFileDto {
	private Integer boardno;
	private String uploadpath;
}
